# 隐藏睡眠闹钟提示 · SleepAlarmHide

目标：iPhone 15 Pro、iOS 17.3.1、relaxin 隐根。只改 SpringBoard 显示，不调用 MobileTimer 或睡眠计划 API；不安排、不取消、不拦截响铃。安装后无设置面板，移除后恢复。

## 测试版安装

1. 通过 Sileo 或当前隐根包管理器打开 `.deb`，确认包为 `com.axs.sleepalarmhide`。若提示架构不兼容或缺依赖，不要强制安装。
2. 安装后 Respring（注销桌面），进入睡眠专注并锁屏。只应消失大时钟下方的起床时间胶囊；底部「睡眠」、大时钟、手电筒和相机应仍在。退出睡眠后再看正常锁屏。
3. 在白天设一个几分钟后的起床测试闹钟，确认能响、能停止。再测试一个普通计时器。没有完成前，不建议拿它测试必须按时响的闹钟。
4. 如果没效果或误隐藏，在包管理器移除插件并 Respring；若 SpringBoard 反复重启，使用当前环境支持的安全模式或禁用插件注入方式启动，再移除。

如果无效，可将 SpringBoard 日志中包含 `AxsSleepAlarmHide` 的行发给开发者。日志只包含匹配结果、候选类、父类视图、尺寸和图像计数，不输出闹钟时间、不上传。若看不到日志，可提供安装提示和安装后截图。

## 实现与验证边界

已参考公开 iOS 17 Runtime Headers 的 `CSCoverSheetView`、`SBFLockScreenDateView`、`FCActivityManager` 与 `_FCActivity`。目标设备上胶囊的专用类尚未实测，因此测试版要求系统识别为睡眠专注、位置处于大时钟附近下方、视图符合胶囊形状特征、包含时间格式及带闹钟语义的图标，并且候选唯一。特征缺失时不改 UI；保留原布局占位。不隐藏通知、计时器或小组件的已知宿主类。

- `python3 BuildSupport/build-linux-test.py`：在 Linux 使用 Clang/LLD/LLVM 和 dpkg 工具构建。包架构为 `iphoneos-arm64e`（Roothide 包格式），内含兼容 `arm64` Mach-O，不是原生 `arm64e`。仅做交叉编译、签名结构、包结构、依赖和过滤器检查；未装机验证注入。
- `ARCHS=...` 通过 make 的命令行变量传入。使用带 iPhoneOS 16.5 SDK 和 Apple 链接器的 roothide/Theos：`sh build.sh roothide`；如只需原生 arm64e，可执行 `make clean THEOS_PACKAGE_SCHEME=roothide ARCHS=arm64e && make package THEOS_PACKAGE_SCHEME=roothide ARCHS=arm64e`。本地未执行这一原生 Theos 构建。
