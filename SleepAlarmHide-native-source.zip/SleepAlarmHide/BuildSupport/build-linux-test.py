#!/usr/bin/env python3
"""Build and inspect the experimental arm64 Mach-O inside a Roothide .deb."""
from pathlib import Path
import os
import plistlib
import shutil
import struct
import subprocess as sp
import tempfile

root = Path(__file__).resolve().parents[1]
name = 'AxsSleepAlarmHide'
ident = 'com.axs.sleepalarmhide'
version = '5.2.0~test3'


def run(*args):
    return sp.check_output([str(x) for x in args], text=True)


with tempfile.TemporaryDirectory(prefix='sleepalarmhide-') as tmp:
    stage = Path(tmp)
    obj = stage / 'Display.o'
    run('clang', '--target=arm64-apple-ios17.0', '-fobjc-arc', '-O2', '-Wall', '-Wextra', '-Werror', '-I', root / 'Headers', '-c', root / 'Sources' / f'{name}Display.m', '-o', obj)
    imports = [line.strip() for line in run('llvm-nm', '-u', obj).splitlines() if line.strip()]
    def library(sym):
        if sym.startswith(('_OBJC_CLASS_$_UI',)):
            return '/System/Library/Frameworks/UIKit.framework/UIKit'
        if sym == '_NSLog' or sym.startswith('_OBJC_CLASS_$_NS'):
            return '/System/Library/Frameworks/Foundation.framework/Foundation'
        if sym == '___CFConstantStringClassReference':
            return '/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation'
        if sym.startswith(('_objc_', '_class_', '_method_', '_object_')):
            return '/usr/lib/libobjc.A.dylib'
        if sym in ('_strstr', '___stack_chk_fail', '___stack_chk_guard'):
            return '/usr/lib/libSystem.B.dylib'
        raise ValueError(f'Unrecognized import: {sym}')
    stubs = []
    for path in sorted({library(s) for s in imports}):
        syms = ', '.join(s for s in imports if library(s) == path)
        stub = stage / (Path(path).name + '.tbd')
        stub.write_text(f'--- !tapi-tbd\ntbd-version: 4\ntargets: [ arm64-ios ]\ninstall-name: {path}\nexports:\n  - targets: [ arm64-ios ]\n    symbols: [ {syms} ]\n...\n')
        stubs.append(stub)
    pkg = stage / 'package'
    control = pkg / 'DEBIAN'
    payload = pkg / 'Library/MobileSubstrate/DynamicLibraries'
    control.mkdir(parents=True)
    payload.mkdir(parents=True)
    dylib = payload / f'{name}.dylib'
    run('ld64.lld', '-arch', 'arm64', '-dylib', '-platform_version', 'ios', '17.0', '16.5', '-adhoc_codesign', '-install_name', f'@loader_path/{name}.dylib', '-o', dylib, obj, *stubs)
    dylib.chmod(0o755)
    binary = dylib.read_bytes()
    assert struct.unpack_from('<IIII', binary) == (0xfeedfacf, 0x100000c, 0, 6)
    assert 'LC_CODE_SIGNATURE' in run('llvm-objdump', '--macho', '--private-headers', dylib)
    filter_file = root / f'{name}.plist'
    assert plistlib.loads(filter_file.read_bytes()) == {'Filter': {'Bundles': ['com.apple.springboard']}}
    shutil.copyfile(filter_file, payload / filter_file.name)
    fields = (root / 'control').read_text().splitlines()
    fields = [s for s in fields if not s.startswith(('Architecture:', 'Version:', 'Icon:', 'Sileodepiction:'))]
    (control / 'control').write_text('\n'.join([*fields, 'Architecture: iphoneos-arm64e', f'Version: {version}']) + '\n')
    packages = root / 'packages'
    packages.mkdir(exist_ok=True)
    output = packages / f'{ident}_{version}_roothide.deb'
    os.environ['SOURCE_DATE_EPOCH'] = '1795482000'
    print(run('dpkg-deb', '--root-owner-group', '-Zgzip', '--build', pkg, output), end='')
    print(run('dpkg-deb', '-I', output), end='')
    print(run('dpkg-deb', '-c', output), end='')
    print(run('llvm-objdump', '--macho', '--dylibs-used', dylib), end='')
