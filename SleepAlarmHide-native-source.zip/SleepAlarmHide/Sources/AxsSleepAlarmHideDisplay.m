#if __has_include(<UIKit/UIKit.h>)
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#include <string.h>
#else
#import "AxsSleepAlarmHideCrossSDK.h"
#endif

#import "AxsSleepAlarmHidePrivate.h"

static IMP axs_sleepalarmhide_original;
static BOOL axs_sleepalarmhide_loggedMiss;
static BOOL axs_sleepalarmhide_loggedMatch;
static BOOL axs_sleepalarmhide_loggedLayout;
static BOOL axs_sleepalarmhide_loggedReady;
static BOOL axs_sleepalarmhide_loggedFocusOff;
static BOOL axs_sleepalarmhide_loggedFocusOn;
static NSString *axs_sleepalarmhide_report;

// SpringBoard's real mobile Media directory, not a jailbreak package resource.
static void axs_sleepalarmhide_record(NSString *line) {
    if (axs_sleepalarmhide_report.length >= 5500) return;
    axs_sleepalarmhide_report = [(axs_sleepalarmhide_report ?: @"SleepAlarmHide test3 (diagnostic only)\n")
        stringByAppendingString:[line stringByAppendingString:@"\n"]];
    if (![axs_sleepalarmhide_report writeToFile:@"/var/mobile/Media/AxsSleepAlarmHide-diagnostic.txt"
                                   atomically:YES encoding:NSUTF8StringEncoding error:NULL])
        NSLog(@"[AxsSleepAlarmHide] diagnostic file write failed: %@", line);
}

static BOOL axs_sleepalarmhide_isSleep(void) {
    Class managerClass = objc_lookUpClass("FCActivityManager");
    if (![managerClass respondsToSelector:@selector(sharedActivityManager)]) return NO;
    id manager = [managerClass sharedActivityManager];
    if (![manager respondsToSelector:@selector(activeActivity)]) return NO;
    id activity = [manager activeActivity];
    if ([activity respondsToSelector:@selector(isSleepActivity)])
        return [activity isSleepActivity];
    return [activity respondsToSelector:@selector(activityIdentifier)] &&
        [[activity activityIdentifier] isEqualToString:@"com.apple.sleep.sleep-mode"];
}

static BOOL axs_sleepalarmhide_inClass(id obj, const char *name) {
    Class c = objc_lookUpClass(name);
    return c && [obj isKindOfClass:c];
}

static BOOL axs_sleepalarmhide_excluded(UIView *view) {
    for (Class c = object_getClass(view); c; c = class_getSuperclass(c)) {
        const char *name = class_getName(c);
        if (strstr(name, "Widget") || strstr(name, "Complication") ||
            strstr(name, "Notification") || strstr(name, "Remote") ||
            strstr(name, "TimerView") || strstr(name, "SubtitleDate") ||
            strstr(name, "FocusActivity")) return YES;
    }
    return NO;
}

static BOOL axs_sleepalarmhide_isAlarmName(NSString *name) {
    if (![name isKindOfClass:[NSString class]]) return NO;
    NSString *n = name.lowercaseString;
    return [n isEqualToString:@"alarm"] || [n hasPrefix:@"alarm."] ||
        [n hasPrefix:@"alarmclock"] || [n hasPrefix:@"wakeup.alarm"] ||
        [n hasPrefix:@"sleep.alarm"] || [n hasPrefix:@"sleepalarm"];
}

static NSString *axs_sleepalarmhide_imageName(UIImage *image) {
    id asset = image.imageAsset;
    id name = [asset respondsToSelector:@selector(assetName)] ? [asset assetName] : nil;
    if (axs_sleepalarmhide_isAlarmName(name)) return name;
    id menuName = [image respondsToSelector:@selector(_asMenuElementImageName)] ?
        [image _asMenuElementImageName] : nil;
    if (axs_sleepalarmhide_isAlarmName(menuName)) return menuName;
    return [name isKindOfClass:[NSString class]] ? name : nil;
}

typedef struct { unsigned time, other, alarm, images, visited; BOOL excluded; } AxsSleepAlarmHideTraits;

static void axs_sleepalarmhide_inspect(UIView *view, UIView *root,
                                     AxsSleepAlarmHideTraits *out, unsigned depth,
                                     NSRegularExpression *pattern) {
    if (depth > 9 || ++out->visited > 90) { out->excluded = YES; return; }
    if (view != root && (view.hidden || view.alpha < .04)) return;
    if (axs_sleepalarmhide_excluded(view)) { out->excluded = YES; return; }
    NSString *text = nil;
    if ([view isKindOfClass:[UILabel class]]) {
        UILabel *label = (UILabel *)view;
        text = label.text ?: label.attributedText.string;
    } else if (axs_sleepalarmhide_inClass(view, "SBUILegibilityLabel") &&
               [view respondsToSelector:@selector(attributedText)]) {
        text = ((NSAttributedString *)[(id)view attributedText]).string;
    }
    if (text.length) {
        if (text.length < 28 && [pattern numberOfMatchesInString:text options:0 range:NSMakeRange(0,text.length)])
            ++out->time;
        else ++out->other;
        return; // UIKit/system legibility labels can carry backing copies of the same text.
    }
    UIImage *image = [view isKindOfClass:[UIImageView class]] ? [(UIImageView *)view image] : nil;
    if (image) {
        ++out->images;
        if (axs_sleepalarmhide_isAlarmName(axs_sleepalarmhide_imageName(image))) ++out->alarm;
    }
    for (UIView *child in view.subviews) {
        axs_sleepalarmhide_inspect(child, root, out, depth+1, pattern);
        if (out->excluded || out->other) break;
    }
}

static BOOL axs_sleepalarmhide_geometry(CGRect f, CGRect canvas, CGRect clock) {
    double w=canvas.size.width, h=canvas.size.height;
    double gap=f.origin.y-(clock.origin.y+clock.size.height);
    double dx=(f.origin.x+f.size.width/2)-(canvas.origin.x+w/2);
    return f.size.width >= .13*w && f.size.width <= .47*w &&
        f.size.height >= 19 && f.size.height <= 59 &&
        dx >= -.14*w && dx <= .14*w && gap >= -18 && gap <= .14*h;
}

static void axs_sleepalarmhide_find(UIView *view, UIView *cover, CGRect clock,
                                   NSRegularExpression *pattern, unsigned depth,
                                   unsigned *budget, UIView *__strong *result, BOOL *ambiguous,
                                   unsigned *diagnostics) {
    if (!*budget || depth>19 || *ambiguous) return;
    --*budget;
    if (view.hidden) return;
    if (view.alpha < .04 || axs_sleepalarmhide_excluded(view)) return;
    CGRect f=[view convertRect:view.bounds toView:cover];
    if (view != cover && axs_sleepalarmhide_geometry(f,cover.bounds,clock)) {
        AxsSleepAlarmHideTraits t={0};
        axs_sleepalarmhide_inspect(view,view,&t,0,pattern);
        if (t.time && !t.other && !t.excluded && *diagnostics) {
            --*diagnostics;
            axs_sleepalarmhide_record([NSString stringWithFormat:@"candidate %s parent %s w=%.0f h=%.0f images=%u alarmIcons=%u",
                object_getClassName(view), object_getClassName(view.superview),
                f.size.width, f.size.height, t.images, t.alarm]);
        }
        if (!t.excluded && !t.other && t.time && t.time<=2 && t.alarm && t.images<=3 &&
            (view.clipsToBounds || view.layer.cornerRadius>=6 || [view isKindOfClass:[UIControl class]] ||
             axs_sleepalarmhide_inClass(view,"SBFLockScreenDateSubtitleView"))) {
            if (*result && *result != view) { *ambiguous=YES; return; }
            *result=view;
            return; // Pick the outer, geometrically constrained pill, not its children.
        }
    }
    for (UIView *child in view.subviews)
        axs_sleepalarmhide_find(child,cover,clock,pattern,depth+1,budget,result,ambiguous,diagnostics);
}

static void axs_sleepalarmhide_layout(UIView *cover, SEL cmd) {
    ((void (*)(id,SEL))axs_sleepalarmhide_original)(cover,cmd);
    if (![NSThread isMainThread]) return;
    if (!axs_sleepalarmhide_loggedLayout) {
        axs_sleepalarmhide_loggedLayout=YES;
        axs_sleepalarmhide_record(@"layout called");
    }
    BOOL ready=cover.window && cover.bounds.size.width < cover.bounds.size.height;
    BOOL sleep=ready && axs_sleepalarmhide_isSleep();
    if (ready && !axs_sleepalarmhide_loggedReady) {
        axs_sleepalarmhide_loggedReady=YES;
        axs_sleepalarmhide_record(@"portrait cover sheet attached");
    }
    if (ready && !sleep && !axs_sleepalarmhide_loggedFocusOff) {
        axs_sleepalarmhide_loggedFocusOff=YES;
        axs_sleepalarmhide_record(@"sleep focus not detected");
    }
    if (!sleep) {
        axs_sleepalarmhide_loggedMiss=NO;
        return;
    }
    if (!axs_sleepalarmhide_loggedFocusOn) {
        axs_sleepalarmhide_loggedFocusOn=YES;
        axs_sleepalarmhide_record(@"sleep focus detected");
    }
    id date=[cover respondsToSelector:@selector(dateView)] ? [(id)cover dateView] : nil;
    UIView *label=[date respondsToSelector:@selector(_timeLabel)] ? [date _timeLabel] : nil;
    CGRect clock={0};
    if ([label isKindOfClass:[UIView class]] && [label isDescendantOfView:cover])
        clock=[label convertRect:label.bounds toView:cover];
    if (clock.size.width < cover.bounds.size.width*.22 || clock.size.height<30 || clock.origin.y<0) {
        if (!axs_sleepalarmhide_loggedMiss) {
            axs_sleepalarmhide_loggedMiss=YES;
            axs_sleepalarmhide_record([NSString stringWithFormat:@"clock geometry unavailable (date=%d timeLabel=%d w=%.0f h=%.0f)", date!=nil, label!=nil, clock.size.width, clock.size.height]);
        }
        return;
    }
    static NSRegularExpression *pattern;
    if (!pattern) pattern=[NSRegularExpression regularExpressionWithPattern:
        @"^[\\p{Z}\\p{Cf} ]*(?:AM|PM|上午|下午)?[\\p{Z}\\p{Cf} ]*\\p{Nd}{1,2}[:：]\\p{Nd}{2}[\\p{Z}\\p{Cf} ]*(?:AM|PM|上午|下午)?[\\p{Z}\\p{Cf} ]*$"
        options:1 error:NULL];
    if (!pattern) return;
    UIView *result=nil;
    BOOL ambiguous=NO;
    unsigned budget=550;
    unsigned diagnostics=(!axs_sleepalarmhide_loggedMiss && !axs_sleepalarmhide_loggedMatch) ? 8 : 0;
    axs_sleepalarmhide_find(cover,cover,clock,pattern,0,&budget,&result,&ambiguous,&diagnostics);
    if (ambiguous || !budget) result=nil;
    if (result && !axs_sleepalarmhide_loggedMatch) {
        axs_sleepalarmhide_loggedMatch=YES;
        axs_sleepalarmhide_record([NSString stringWithFormat:@"matched pill class: %s; diagnostics only",object_getClassName(result)]);
    } else if (!result && !axs_sleepalarmhide_loggedMiss) {
        axs_sleepalarmhide_loggedMiss=YES;
        axs_sleepalarmhide_record([NSString stringWithFormat:@"no unique match (ambiguous=%d budget=%u)",ambiguous,budget]);
    }
}

__attribute__((constructor)) static void axs_sleepalarmhide_install(void) {
    @autoreleasepool {
        if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.apple.springboard"]) return;
        axs_sleepalarmhide_record(@"dylib loaded into SpringBoard");
        if ([NSProcessInfo processInfo].operatingSystemVersion.majorVersion != 17) {
            axs_sleepalarmhide_record(@"unsupported iOS major version");
            return;
        }
        Class cls=objc_lookUpClass("CSCoverSheetView");
        SEL sel=@selector(layoutSubviews);
        Method meth=cls ? class_getInstanceMethod(cls,sel) : NULL;
        if (!meth) {
            axs_sleepalarmhide_record(@"CSCoverSheetView/layoutSubviews not found at load time");
            return;
        }
        axs_sleepalarmhide_original=method_getImplementation(meth);
        IMP replacement=(IMP)axs_sleepalarmhide_layout;
        if (!class_addMethod(cls,sel,replacement,method_getTypeEncoding(meth)))
            class_replaceMethod(cls,sel,replacement,method_getTypeEncoding(meth));
        axs_sleepalarmhide_record(@"layout hook installed");
    }
}
