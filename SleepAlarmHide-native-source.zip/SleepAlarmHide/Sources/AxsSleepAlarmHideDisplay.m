#if __has_include(<UIKit/UIKit.h>)
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <dispatch/dispatch.h>
#include <string.h>
#else
#import "AxsSleepAlarmHideCrossSDK.h"
#endif

#import "AxsSleepAlarmHidePrivate.h"

static IMP axs_sleepalarmhide_original;
static BOOL axs_sleepalarmhide_pending;
static unsigned axs_sleepalarmhide_samples;
static NSString *axs_sleepalarmhide_report;

// SpringBoard's real mobile Media directory, not a jailbreak package resource.
static void axs_sleepalarmhide_record(NSString *line) {
    if (axs_sleepalarmhide_report.length >= 14000) return;
    axs_sleepalarmhide_report = [(axs_sleepalarmhide_report ?: @"SleepAlarmHide native3 (diagnostic only)\n")
        stringByAppendingString:[line stringByAppendingString:@"\n"]];
    if (![axs_sleepalarmhide_report writeToFile:@"/var/mobile/Media/AxsSleepAlarmHide-diagnostic.txt"
                                   atomically:YES encoding:NSUTF8StringEncoding error:NULL])
        NSLog(@"[AxsSleepAlarmHide] diagnostic file write failed: %@", line);
}

static BOOL axs_sleepalarmhide_isSleep(void) {
    Class managerClass = objc_lookUpClass("FCActivityManager");
    if (![managerClass respondsToSelector:@selector(sharedActivityManager)]) return NO;
    id manager = [managerClass sharedActivityManager];
    if (![manager respondsToSelector:@selector(activeActivity)]) return NO;
    id activity = [manager activeActivity];
    if ([activity respondsToSelector:@selector(isSleepActivity)])
        return [activity isSleepActivity];
    return [activity respondsToSelector:@selector(activityIdentifier)] &&
        [[activity activityIdentifier] isEqualToString:@"com.apple.sleep.sleep-mode"];
}

// Look at the actual on-screen area from the screenshot, independent of clock labels.
static void axs_sleepalarmhide_trace(UIView *view, UIWindow *window, CGRect target,
                                    unsigned depth, unsigned *budget, unsigned *lines) {
    if (!*budget || !*lines || depth>28 || view.hidden || view.alpha < .04) return;
    --*budget;
    CGRect f=[view convertRect:view.bounds toView:window];
    CGFloat cx=CGRectGetMidX(target), cy=CGRectGetMidY(target);
    BOOL intersects=CGRectIntersectsRect(f,target);
    if (!intersects && view.clipsToBounds) return;
    if (intersects && view != window && f.size.width <= window.bounds.size.width*.68 &&
        f.size.height <= 125 && f.size.width >= 6 && f.size.height >= 6) {
        --*lines;
        UIView *parent=view.superview;
        UIView *grand=parent.superview;
        axs_sleepalarmhide_record([NSString stringWithFormat:
            @"  %u %s < %s < %s dx=%.0f dy=%.0f w=%.0f h=%.0f radius=%.0f layers=%lu",
            depth,object_getClassName(view),parent?object_getClassName(parent):"-",
            grand?object_getClassName(grand):"-",CGRectGetMidX(f)-cx,CGRectGetMidY(f)-cy,
            f.size.width,f.size.height,view.layer.cornerRadius,(unsigned long)view.layer.sublayers.count]);
    }
    for (UIView *child in view.subviews.reverseObjectEnumerator)
        axs_sleepalarmhide_trace(child,window,target,depth+1,budget,lines);
}

static void axs_sleepalarmhide_traceWindow(UIWindow *window, unsigned maxLines) {
    CGRect b=window.bounds;
    if (window.hidden || window.alpha<.04 || b.size.width<200 || b.size.height<=b.size.width) return;
    CGRect target=CGRectMake(CGRectGetMidX(b)-b.size.width*.19,
                           b.origin.y+b.size.height*.253,b.size.width*.38,b.size.height*.085);
    unsigned budget=1500, lines=maxLines;
    axs_sleepalarmhide_record([NSString stringWithFormat:@"window %s %.0fx%.0f",object_getClassName(window),b.size.width,b.size.height]);
    axs_sleepalarmhide_trace(window,window,target,0,&budget,&lines);
    if (lines==maxLines) axs_sleepalarmhide_record(@"  no small local views in target area");
}

static BOOL axs_sleepalarmhide_ready(UIView *cover) {
    return cover.window && !cover.hidden && cover.alpha >= .04 &&
        cover.bounds.size.width > 0 && cover.bounds.size.width < cover.bounds.size.height;
}

static void axs_sleepalarmhide_sample(UIView *cover) {
    if (!axs_sleepalarmhide_ready(cover) || !axs_sleepalarmhide_isSleep()) return;
    ++axs_sleepalarmhide_samples;
    axs_sleepalarmhide_record([NSString stringWithFormat:@"sample %u: sleep focus=%d", axs_sleepalarmhide_samples, axs_sleepalarmhide_isSleep()]);
    UIWindow *primary=cover.window;
    axs_sleepalarmhide_traceWindow(primary,20);
    unsigned others=0;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        UIWindowScene *ws=(UIWindowScene *)scene;
        if (ws.screen != primary.screen) continue;
        for (UIWindow *window in ws.windows) {
            if (window==primary || window.hidden || window.alpha<.04 || window.bounds.size.width<200 ||
                window.bounds.size.height<=window.bounds.size.width) continue;
            axs_sleepalarmhide_traceWindow(window,7);
            if (++others>=4) return;
        }
    }
}

static void axs_sleepalarmhide_queueSample(UIView *cover) {
    if (axs_sleepalarmhide_pending || axs_sleepalarmhide_samples >= 5 || !axs_sleepalarmhide_ready(cover)) return;
    if (axs_sleepalarmhide_samples == 0 && ![[NSFileManager defaultManager]
            fileExistsAtPath:@"/var/mobile/Media/AxsSleepAlarmHideCapture"]) return;
    axs_sleepalarmhide_pending=YES;
    __weak UIView *weakCover=cover;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3000000000LL), dispatch_get_main_queue(), ^{
        axs_sleepalarmhide_pending=NO;
        UIView *shown=weakCover;
        if (!shown || !axs_sleepalarmhide_ready(shown) || !axs_sleepalarmhide_isSleep()) return;
        axs_sleepalarmhide_sample(shown);
        axs_sleepalarmhide_queueSample(shown);
    });
}

static void axs_sleepalarmhide_layout(UIView *cover, SEL cmd) {
    ((void (*)(id,SEL))axs_sleepalarmhide_original)(cover,cmd);
    if ([NSThread isMainThread]) axs_sleepalarmhide_queueSample(cover);
}

__attribute__((constructor)) static void axs_sleepalarmhide_install(void) {
    @autoreleasepool {
        if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.apple.springboard"]) return;
        axs_sleepalarmhide_record(@"dylib loaded into SpringBoard");
        if ([NSProcessInfo processInfo].operatingSystemVersion.majorVersion != 17) {
            axs_sleepalarmhide_record(@"unsupported iOS major version");
            return;
        }
        Class cls=objc_lookUpClass("CSCoverSheetView");
        SEL sel=@selector(layoutSubviews);
        Method meth=cls ? class_getInstanceMethod(cls,sel) : NULL;
        if (!meth) {
            axs_sleepalarmhide_record(@"CSCoverSheetView/layoutSubviews not found at load time");
            return;
        }
        axs_sleepalarmhide_original=method_getImplementation(meth);
        IMP replacement=(IMP)axs_sleepalarmhide_layout;
        if (!class_addMethod(cls,sel,replacement,method_getTypeEncoding(meth)))
            class_replaceMethod(cls,sel,replacement,method_getTypeEncoding(meth));
        axs_sleepalarmhide_record(@"layout hook installed; waiting for AxsSleepAlarmHideCapture marker");
    }
}
