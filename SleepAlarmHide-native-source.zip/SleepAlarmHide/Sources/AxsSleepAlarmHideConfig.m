#import "AxsSleepAlarmHideConfig.h"
#import "AxsSleepAlarmHidePreferences.h"

@interface AxsSleepAlarmHideConfig ()
@property (atomic, copy) NSDictionary *snapshot;
@property (nonatomic, strong) dispatch_queue_t reloadQueue;
@end

static void axs_sleepalarmhide_preferencesDidChange(CFNotificationCenterRef center, void *observer,
                                          CFStringRef name, const void *object, CFDictionaryRef info) {
    AxsSleepAlarmHideConfig *config = (__bridge AxsSleepAlarmHideConfig *)observer;
    dispatch_async(config.reloadQueue, ^{
        [config axs_sleepalarmhide_reload];
    });
}

@implementation AxsSleepAlarmHideConfig

+ (instancetype)axs_sleepalarmhide_shared {
    static AxsSleepAlarmHideConfig *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _reloadQueue = dispatch_queue_create("com.axs.sleepalarmhide.preferences", DISPATCH_QUEUE_SERIAL);
        [self axs_sleepalarmhide_reload];
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
            (__bridge const void *)self, axs_sleepalarmhide_preferencesDidChange,
            (__bridge CFStringRef)AxsSleepAlarmHidePreferencesChanged, NULL,
            CFNotificationSuspensionBehaviorDeliverImmediately);
        // Close the window between the first read and observer registration.
        dispatch_async(_reloadQueue, ^{ [self axs_sleepalarmhide_reload]; });
    }
    return self;
}

- (void)axs_sleepalarmhide_reload {
    self.snapshot = axs_sleepalarmhide_readPreferences();
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:AxsSleepAlarmHidePreferencesChanged object:self];
    });
}

- (id)axs_sleepalarmhide_valueForKey:(NSString *)key defaultValue:(id)defaultValue {
    return self.snapshot[key] ?: defaultValue;
}

- (BOOL)axs_sleepalarmhide_isEnabled {
    id value = [self axs_sleepalarmhide_valueForKey:@"enabled" defaultValue:@(YES)];
    return [value isKindOfClass:[NSNumber class]] ? [value boolValue] : YES;
}

- (void)dealloc {
    CFNotificationCenterRemoveEveryObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                            (__bridge const void *)self);
}

@end
