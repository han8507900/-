#pragma once

#import <Foundation/Foundation.h>

@interface AxsSleepAlarmHideConfig : NSObject
+ (instancetype)axs_sleepalarmhide_shared;
- (BOOL)axs_sleepalarmhide_isEnabled;
- (id)axs_sleepalarmhide_valueForKey:(NSString *)key defaultValue:(id)defaultValue;
- (void)axs_sleepalarmhide_reload;
@end
