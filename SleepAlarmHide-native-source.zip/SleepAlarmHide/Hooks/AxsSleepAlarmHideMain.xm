// Runtime hook and matching live in Sources/AxsSleepAlarmHideDisplay.m.
