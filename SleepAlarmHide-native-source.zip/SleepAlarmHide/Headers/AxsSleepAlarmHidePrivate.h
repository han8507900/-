#pragma once

// System selectors listed in the public iOS 17 runtime headers; all calls guarded.
@interface NSObject (AxsSleepAlarmHideRuntimeDeclarations)
- (id)dateView;
- (id)_timeLabel;
+ (id)sharedActivityManager;
- (id)activeActivity;
- (BOOL)isSleepActivity;
- (id)activityIdentifier;
- (id)assetName;
- (id)_asMenuElementImageName;
@end
