#pragma once
// SDK-free clang declarations for the Linux test build only. Theos uses the real SDK.
#include <stddef.h>
#if !__has_feature(objc_arc)
#error ARC required
#endif
#define nil ((id)0)
#define YES __objc_yes
#define NO __objc_no
typedef _Bool BOOL;
typedef unsigned long NSUInteger;
typedef long NSInteger;
typedef struct { NSUInteger location,length; } NSRange;
static inline NSRange NSMakeRange(NSUInteger p, NSUInteger n) { return (NSRange){p,n}; }
typedef struct CGPoint {double x,y;} CGPoint;
typedef struct CGSize {double width,height;} CGSize;
typedef struct CGRect {CGPoint origin; CGSize size;} CGRect;
typedef struct {NSInteger majorVersion, minorVersion, patchVersion;} NSOperatingSystemVersion;
typedef struct objc_method *Method;
typedef void (*IMP)(void);
extern Class objc_lookUpClass(const char *);
extern Class object_getClass(id);
extern const char *object_getClassName(id);
extern const char *class_getName(Class);
extern Class class_getSuperclass(Class);
extern Method class_getInstanceMethod(Class, SEL);
extern IMP method_getImplementation(Method);
extern const char *method_getTypeEncoding(Method);
extern BOOL class_addMethod(Class, SEL, IMP, const char *);
extern IMP class_replaceMethod(Class, SEL, IMP, const char *);
extern char *strstr(const char *,const char *);
__attribute__((objc_root_class)) @interface NSObject
+ (Class)class;
+ (BOOL)respondsToSelector:(SEL)s;
- (BOOL)respondsToSelector:(SEL)s;
- (BOOL)isKindOfClass:(Class)c;
@end
@class NSString, NSError;
extern void NSLog(NSString *, ...);
@interface NSString:NSObject
@property(readonly) NSUInteger length;
@property(readonly) NSString *lowercaseString;
- (BOOL)hasPrefix:(NSString *)s;
- (BOOL)isEqualToString:(NSString *)s;
+ (instancetype)stringWithFormat:(NSString *)format, ...;
- (NSString *)stringByAppendingString:(NSString *)s;
- (BOOL)writeToFile:(NSString *)path atomically:(BOOL)atomic encoding:(NSUInteger)encoding error:(NSError **)error;
#define NSUTF8StringEncoding 4
@end
@interface NSAttributedString:NSObject
@property(readonly) NSString *string;
@end
typedef struct {unsigned long state; id __unsafe_unretained *itemsPtr; unsigned long *mutationsPtr; unsigned long extra[5];} NSFastEnumerationState;
@interface NSArray<__covariant T>:NSObject
- (NSUInteger)countByEnumeratingWithState:(NSFastEnumerationState *)s objects:(id __unsafe_unretained[])o count:(NSUInteger)n;
@end
@interface NSBundle:NSObject
+ (NSBundle *)mainBundle;
@property(readonly) NSString *bundleIdentifier;
@end
@interface NSProcessInfo:NSObject
+ (NSProcessInfo *)processInfo;
@property(readonly) NSOperatingSystemVersion operatingSystemVersion;
@end
@interface NSThread:NSObject
+ (BOOL)isMainThread;
@end
@interface NSRegularExpression:NSObject
+ (instancetype)regularExpressionWithPattern:(NSString *)p options:(NSUInteger)o error:(NSError **)e;
- (NSUInteger)numberOfMatchesInString:(NSString *)s options:(NSUInteger)o range:(NSRange)r;
@end
@interface CALayer:NSObject
@property(readonly) double cornerRadius;
@end
@class UIWindow, UIImageAsset;
@interface UIView:NSObject
@property(readonly) CGRect bounds;
@property(readonly) NSArray<UIView *> *subviews;
@property(readonly) UIWindow *window;
@property(readonly) UIView *superview;
@property(readonly) double alpha;
@property(getter=isHidden) BOOL hidden;
@property(readonly) BOOL clipsToBounds;
@property(readonly) CALayer *layer;
- (CGRect)convertRect:(CGRect)r toView:(UIView *)v;
- (BOOL)isDescendantOfView:(UIView *)v;
- (void)layoutSubviews;
@end
@interface UIImage:NSObject
@property(readonly) UIImageAsset *imageAsset;
@end
@interface UIImageView:UIView
@property(readonly) UIImage *image;
@end
@interface UILabel:UIView
@property(readonly) NSString *text;
@property(readonly) NSAttributedString *attributedText;
@end
@interface UIControl:UIView @end
