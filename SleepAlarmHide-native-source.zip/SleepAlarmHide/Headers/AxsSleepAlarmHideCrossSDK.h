#pragma once
// SDK-free clang declarations for the Linux test build only. Theos uses the real SDK.
#include <stddef.h>
typedef unsigned long long dispatch_time_t;
typedef void *dispatch_queue_t;
extern struct dispatch_queue_s _dispatch_main_q;
#define DISPATCH_TIME_NOW 0
#define dispatch_get_main_queue() ((dispatch_queue_t)&_dispatch_main_q)
extern dispatch_time_t dispatch_time(dispatch_time_t, long long);
extern void dispatch_after(dispatch_time_t, dispatch_queue_t, void (^)(void));
#if !__has_feature(objc_arc)
#error ARC required
#endif
#define nil ((id)0)
#define YES __objc_yes
#define NO __objc_no
typedef _Bool BOOL;
typedef unsigned long NSUInteger;
typedef long NSInteger;
typedef struct { NSUInteger location,length; } NSRange;
static inline NSRange NSMakeRange(NSUInteger p, NSUInteger n) { return (NSRange){p,n}; }
typedef struct CGPoint {double x,y;} CGPoint;
typedef struct CGSize {double width,height;} CGSize;
typedef struct CGRect {CGPoint origin; CGSize size;} CGRect;
typedef struct {NSInteger majorVersion, minorVersion, patchVersion;} NSOperatingSystemVersion;
typedef struct objc_method *Method;
typedef void (*IMP)(void);
extern Class objc_lookUpClass(const char *);
extern Class object_getClass(id);
extern const char *object_getClassName(id);
extern const char *class_getName(Class);
extern Class class_getSuperclass(Class);
extern Method class_getInstanceMethod(Class, SEL);
extern IMP method_getImplementation(Method);
extern const char *method_getTypeEncoding(Method);
extern BOOL class_addMethod(Class, SEL, IMP, const char *);
extern IMP class_replaceMethod(Class, SEL, IMP, const char *);
extern char *strstr(const char *,const char *);
__attribute__((objc_root_class)) @interface NSObject
+ (Class)class;
+ (BOOL)respondsToSelector:(SEL)s;
- (BOOL)respondsToSelector:(SEL)s;
- (BOOL)isKindOfClass:(Class)c;
@end
@class NSString, NSError;
extern void NSLog(NSString *, ...);
@interface NSString:NSObject
@property(readonly) NSUInteger length;
@property(readonly) NSString *lowercaseString;
- (BOOL)hasPrefix:(NSString *)s;
- (BOOL)isEqualToString:(NSString *)s;
+ (instancetype)stringWithFormat:(NSString *)format, ...;
- (NSString *)stringByAppendingString:(NSString *)s;
- (BOOL)writeToFile:(NSString *)path atomically:(BOOL)atomic encoding:(NSUInteger)encoding error:(NSError **)error;
#define NSUTF8StringEncoding 4
@end
@interface NSAttributedString:NSObject
@property(readonly) NSString *string;
@end
typedef struct {unsigned long state; id __unsafe_unretained *itemsPtr; unsigned long *mutationsPtr; unsigned long extra[5];} NSFastEnumerationState;
@interface NSArray<__covariant T>:NSObject
- (NSUInteger)countByEnumeratingWithState:(NSFastEnumerationState *)s objects:(id __unsafe_unretained[])o count:(NSUInteger)n;
@end
@interface NSBundle:NSObject
+ (NSBundle *)mainBundle;
@property(readonly) NSString *bundleIdentifier;
@end
@interface NSProcessInfo:NSObject
+ (NSProcessInfo *)processInfo;
@property(readonly) NSOperatingSystemVersion operatingSystemVersion;
@end
@interface NSFileManager:NSObject
+ (NSFileManager *)defaultManager;
- (BOOL)fileExistsAtPath:(NSString *)path;
@end
@interface NSThread:NSObject
+ (BOOL)isMainThread;
@end
@interface NSRegularExpression:NSObject
+ (instancetype)regularExpressionWithPattern:(NSString *)p options:(NSUInteger)o error:(NSError **)e;
- (NSUInteger)numberOfMatchesInString:(NSString *)s options:(NSUInteger)o range:(NSRange)r;
@end
typedef double CGFloat;
#define CGRectMake(x,y,w,h) ((CGRect){{(x),(y)},{(w),(h)}})
#define CGRectGetMidX(r) ((r).origin.x + (r).size.width*.5)
#define CGRectGetMidY(r) ((r).origin.y + (r).size.height*.5)
#define CGRectIntersectsRect(a,b) ((a).origin.x < (b).origin.x+(b).size.width && (b).origin.x < (a).origin.x+(a).size.width && (a).origin.y < (b).origin.y+(b).size.height && (b).origin.y < (a).origin.y+(a).size.height)
@interface NSArray<T> (AxsSleepAlarmHideWindowSDK)
@property(readonly) NSUInteger count;
@property(readonly) NSArray<T> *reverseObjectEnumerator;
@end
@interface CALayer:NSObject
@property(readonly) double cornerRadius;
@property(readonly) NSArray<CALayer *> *sublayers;
@end
@class UIWindow, UIImageAsset;
@interface UIView:NSObject
@property(readonly) CGRect bounds;
@property(readonly) NSArray<UIView *> *subviews;
@property(readonly) UIWindow *window;
@property(readonly) UIView *superview;
@property(readonly) double alpha;
@property(getter=isHidden) BOOL hidden;
@property(readonly) BOOL clipsToBounds;
@property(readonly) CALayer *layer;
- (CGRect)convertRect:(CGRect)r toView:(UIView *)v;
- (BOOL)isDescendantOfView:(UIView *)v;
- (void)layoutSubviews;
@end
@interface UIWindow:UIView
@property(readonly) id screen;
@end
@interface UIScene:NSObject @end
@interface UIWindowScene:UIScene
@property(readonly) id screen;
@property(readonly) NSArray<UIWindow *> *windows;
@end
@interface UIApplication:NSObject
+ (UIApplication *)sharedApplication;
@property(readonly) NSArray<UIScene *> *connectedScenes;
@end
@interface UIImage:NSObject
@property(readonly) UIImageAsset *imageAsset;
@end
@interface UIImageView:UIView
@property(readonly) UIImage *image;
@end
@interface UILabel:UIView
@property(readonly) NSString *text;
@property(readonly) NSAttributedString *attributedText;
@end
@interface UIControl:UIView @end
